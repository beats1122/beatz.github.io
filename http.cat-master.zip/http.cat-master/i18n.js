module.exports = {
  locales: ['en', 'ca'],
  defaultLocale: 'en',
  pages: {
    '*': ['common'],
  },
};
