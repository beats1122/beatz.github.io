export { default } from './Thumbnail'
